# 6. Melakukan *Looping* Menggunakan `While`

## Objectives

* Mengerti Cara Melakukan *Looping* Menggunakan `While`

## Directions

Tugas ini sangat mirip dengan tugas [sebelumnya](./anchor-belajar-for.md), hanya saja untuk menyelesaikan tugas ini, *syntax* yang harus digunakan adalah `while`. Perhatikan *output* yang diinginkan dan implementasikan solusimu!

## Output

```
2 - I love coding
4 - I love coding
6 - I love coding
8 - I love coding
10 - I love coding
12 - I love coding
14 - I love coding
16 - I love coding
18 - I love coding
20 - I love coding
20 - I will become fullstack developer
18 - I will become fullstack developer                                                                              
16 - I will become fullstack developer
14 - I will become fullstack developer
12 - I will become fullstack developer
10 - I will become fullstack developer
8 - I will become fullstack developer
6 - I will become fullstack developer
4 - I will become fullstack developer
2 - I will become fullstack developer
```
